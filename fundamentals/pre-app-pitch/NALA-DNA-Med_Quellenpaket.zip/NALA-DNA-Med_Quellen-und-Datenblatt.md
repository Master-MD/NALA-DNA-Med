# NALA-DNA-Med aPP - Quellen- und Datenblatt

Version: 0.1 Konzept / MVP-Quellenpaket · Stand: 27. Mai 2026 · Repo: https://github.com/Master-MD/NALA-DNA-Med-

> NALA-DNA-Med ist ein Forschungs-/Hypothesen-System, nicht validiert für Diagnose, Therapie oder klinische Entscheidung.

## Executive Summary

Lokale privacy-first Plattform mit Multi-User-Zugriff, Tenant-Isolation, RAG-Vault, BioModel-Service als Stub und späterer MAMMAL/RDKit-Integration.

## Quellen

### GitHub: BiomedSciAI/biomed-multi-alignment

- Bereich: Biomedical Foundation Model / MAMMAL
- Link: https://github.com/BiomedSciAI/biomed-multi-alignment
- Original-Kernaussage / Zusammenfassung: Repository describes ibm/biomed.omics.bl.sm.ma-ted-458m as a biomedical foundation model trained on over 2 billion biological samples across proteins, small molecules and single-cell gene data. It positions the model for tasks across the drug-discovery pipeline and provides code/weights references under Apache-2.0.
- Relevanz für NALA-DNA-Med: Primary technical source for later MAMMAL integration. For v0.1 the app should only include a stub service and integration notes, not auto-download large model weights.

### Hugging Face: ibm-research/biomed.omics.bl.sm.ma-ted-458m

- Bereich: Biomedical Foundation Model / MAMMAL
- Link: https://huggingface.co/ibm-research/biomed.omics.bl.sm.ma-ted-458m
- Original-Kernaussage / Zusammenfassung: Model card states that the model is a biomedical foundation model trained on over 2 billion biological samples across modalities including proteins, small molecules and single-cell gene data. It is designed for robust performance across biomedical and drug-discovery tasks.
- Relevanz für NALA-DNA-Med: Reference for model download location, model size family (~0.5B), intended input domains, and future plugin target.

### arXiv: MAMMAL - Molecular Aligned Multi-Modal Architecture and Language

- Bereich: Biomedical Foundation Model / MAMMAL
- Link: https://arxiv.org/abs/2410.22367
- Original-Kernaussage / Zusammenfassung: Paper presents MAMMAL as a multi-modal biomedical architecture aligning molecular, protein and omics data. It states that model code and pretrained weights are publicly available through GitHub and Hugging Face.
- Relevanz für NALA-DNA-Med: Scientific background for the BioLab concept. Use as citation for why molecule/protein/omics workflows belong in the app, while still labelling outputs as research-support only.

### IBM Research: Biomedical Foundation Models

- Bereich: Biomedical Foundation Models / IBM
- Link: https://research.ibm.com/projects/biomedical-foundation-models
- Original-Kernaussage / Zusammenfassung: IBM Research describes biomedical foundation model technologies that use multimodal biomedical data such as drug-like small molecules, proteins and single-cell RNA sequence data, with research expertise spanning chemistry, AI, biology and biomedical informatics.
- Relevanz für NALA-DNA-Med: High-level institutional context for committees/doctors: this approach is an active research direction, not a random hobby stack.

### Qdrant Documentation: Multitenancy

- Bereich: Multitenancy / Data Isolation
- Link: https://qdrant.tech/documentation/manage-data/multitenancy/
- Original-Kernaussage / Zusammenfassung: Qdrant recommends, in many cases, using a single collection per embedding model with payload-based partitioning for tenants and use cases. The documentation also discusses tiered multitenancy and per-tenant isolation/performance considerations.
- Relevanz für NALA-DNA-Med: Core source for RAGVault design: every vector payload must include tenant_id, user_id, project_id and document_id, and every retrieval query must enforce filters.

### Qdrant Article: How to Implement Multitenancy and Custom Sharding

- Bereich: Multitenancy / Data Isolation
- Link: https://qdrant.tech/articles/multitenancy/
- Original-Kernaussage / Zusammenfassung: Qdrant article explains that vectors can share a collection while being separated by tenant-specific payload metadata. Tenant payloads enable filtering and large-scale multitenant setups.
- Relevanz für NALA-DNA-Med: Supports the TenantShield rule: shared infrastructure is OK, but every stored vector/document must carry tenant metadata.

### Open WebUI Documentation: Features / Authentication & Access

- Bereich: Multi-User Frontend / RBAC
- Link: https://docs.openwebui.com/features/
- Original-Kernaussage / Zusammenfassung: Open WebUI documentation says the platform is multi-user from day one, with roles, groups, per-model access and identity-provider integration.
- Relevanz für NALA-DNA-Med: Good MVP option for a ready-made multi-user chat UI before building a fully custom NALA Black Edition interface.

### Open WebUI Documentation: Role-Based Access Control

- Bereich: Multi-User Frontend / RBAC
- Link: https://docs.openwebui.com/features/authentication-access/rbac/
- Original-Kernaussage / Zusammenfassung: RBAC guide covers roles, permissions, groups and security/privacy configuration. It explicitly separates role management from granular permission toggles.
- Relevanz für NALA-DNA-Med: Reference for roles such as Admin, User, Pending, and for designing doctors/researcher/viewer/admin workflows.

### Open WebUI Documentation: Roles

- Bereich: Multi-User Frontend / RBAC
- Link: https://docs.openwebui.com/features/authentication-access/rbac/roles/
- Original-Kernaussage / Zusammenfassung: Open WebUI defines primary system roles: Admin as superuser with full control, User as standard RBAC-governed account, and Pending as restricted until approved.
- Relevanz für NALA-DNA-Med: Useful for CAVEMAN-level role mapping: Owner/Admin/Doctor/Researcher/Viewer/Guest/Pending.

### vLLM Documentation: OpenAI-Compatible Server

- Bereich: LLM Serving / Model Backend
- Link: https://docs.vllm.ai/en/stable/serving/openai_compatible_server/
- Original-Kernaussage / Zusammenfassung: vLLM provides an HTTP server implementing OpenAI-compatible Completions and Chat APIs so models can be served and accessed via standard HTTP clients.
- Relevanz für NALA-DNA-Med: Supports NALA-cORe backend strategy: serve local LLMs behind an OpenAI-compatible interface for UI/agent compatibility.

### vLLM Documentation: Quickstart

- Bereich: LLM Serving / Model Backend
- Link: https://docs.vllm.ai/en/stable/getting_started/quickstart/
- Original-Kernaussage / Zusammenfassung: Quickstart explains vLLM can be deployed as a server implementing the OpenAI API protocol and used as a drop-in replacement for OpenAI API applications.
- Relevanz für NALA-DNA-Med: Good source for why NALA can support interchangeable local/remote LLM backends with the same app interface.

### OrbStack Docs: Docker Containers

- Bereich: macOS Runtime / Container Mode
- Link: https://docs.orbstack.dev/docker/
- Original-Kernaussage / Zusammenfassung: OrbStack includes a Docker engine for running containers. Networking, port forwarding, bind mounts and volumes work with Docker-compatible workflows.
- Relevanz für NALA-DNA-Med: Main source for choosing OrbStack Core Mode for Qdrant/Postgres/MinIO/Redis/BioModel workers on Mac.

### OrbStack Quick Start

- Bereich: macOS Runtime / Container Mode
- Link: https://orbstack.dev/docs/quick-start
- Original-Kernaussage / Zusammenfassung: Quick Start describes setting up Docker containers and full Linux machines on Mac, with Homebrew install option and simple docker run example.
- Relevanz für NALA-DNA-Med: CAVEMAN install source: install OrbStack, run Docker Compose, then start NALA Core Mode.

### OrbStack Native Files / Container, Image, Volume Files

- Bereich: macOS Runtime / Container Mode
- Link: https://docs.orbstack.dev/features/native-files
- Original-Kernaussage / Zusammenfassung: OrbStack exposes container, image, volume and machine files natively to macOS through Finder and CLI-friendly paths.
- Relevanz für NALA-DNA-Med: Important UX benefit for Mike/NALA: users can inspect container files without deep Docker kung-fu.

### Apple Developer: Accelerated PyTorch Training on Mac

- Bereich: Apple Silicon / Local Inference
- Link: https://developer.apple.com/metal/pytorch/
- Original-Kernaussage / Zusammenfassung: Apple explains that PyTorch can use Metal Performance Shaders (MPS) backend for GPU acceleration on Mac, with kernels optimized for Metal GPU families.
- Relevanz für NALA-DNA-Med: Supports Local Lite Mode on MacBook Pro, but with a CPU fallback because not every model/op is guaranteed to behave identically.

### PyTorch Documentation: MPS Backend

- Bereich: Apple Silicon / Local Inference
- Link: https://docs.pytorch.org/docs/stable/notes/mps.html
- Original-Kernaussage / Zusammenfassung: PyTorch notes describe the MPS backend as extending the PyTorch ecosystem so scripts can set up and run operations on GPU on macOS devices.
- Relevanz für NALA-DNA-Med: Source for device detection logic: torch.backends.mps.is_available(), then fallback to CPU.

### RDKit GitHub Repository

- Bereich: Cheminformatics / Molecule Tools
- Link: https://github.com/rdkit/rdkit
- Original-Kernaussage / Zusammenfassung: RDKit is described as a collection of cheminformatics and machine-learning software written in C++ and Python, supporting molecular operations, descriptors, fingerprints and Python wrappers.
- Relevanz für NALA-DNA-Med: Future plugin dependency for SMILES validation, molecule descriptors, fingerprints and molecule preprocessing.

### RDKit Documentation: Getting Started in Python

- Bereich: Cheminformatics / Molecule Tools
- Link: https://www.rdkit.org/docs/GettingStartedInPython.html
- Original-Kernaussage / Zusammenfassung: RDKit getting-started page gives an overview of using RDKit functionality from Python and is framed as an introductory guide rather than a full manual.
- Relevanz für NALA-DNA-Med: Good developer onboarding source for Codex and future NALA-DNA-Med plugin work.

### FastAPI Documentation

- Bereich: Application Backend / API
- Link: https://fastapi.tiangolo.com/
- Original-Kernaussage / Zusammenfassung: FastAPI is a modern Python web framework for building APIs with Python type hints, interactive documentation and high performance characteristics.
- Relevanz für NALA-DNA-Med: Suitable framework for nala-api and biomodel-api because it is simple, typed, testable and Swagger-friendly.

### PostgreSQL Documentation

- Bereich: Databases / Storage
- Link: https://www.postgresql.org/docs/
- Original-Kernaussage / Zusammenfassung: PostgreSQL documentation covers the relational database system used for structured metadata, transactions, users, projects and audit records.
- Relevanz für NALA-DNA-Med: Best fit for tenants/users/projects/jobs/audit_events tables.

### MinIO Documentation

- Bereich: Databases / Storage
- Link: https://min.io/docs/minio/container/index.html
- Original-Kernaussage / Zusammenfassung: MinIO documentation covers S3-compatible object storage in containerized deployments and related administration/deployment concepts.
- Relevanz für NALA-DNA-Med: Fits upload/file vault storage for PDFs, CSVs, FASTA files and generated reports.

### Redis Documentation

- Bereich: Queue / Jobs
- Link: https://redis.io/docs/latest/
- Original-Kernaussage / Zusammenfassung: Redis documentation covers Redis as an in-memory data store often used for caching, queues and fast coordination tasks.
- Relevanz für NALA-DNA-Med: Useful for JobForge queue: background BioModel tasks, indexing jobs, document parsing and status updates.

### Vite Documentation

- Bereich: Frontend / App Build
- Link: https://vite.dev/guide/
- Original-Kernaussage / Zusammenfassung: Vite documentation describes a fast frontend build tool and development server for modern web projects.
- Relevanz für NALA-DNA-Med: Good default for React + TypeScript UI, fast enough for Codex-generated MVP and local iteration.

### Tailwind CSS Documentation

- Bereich: Frontend / UI Styling
- Link: https://tailwindcss.com/docs
- Original-Kernaussage / Zusammenfassung: Tailwind CSS documentation describes utility-first CSS classes for rapidly building custom UI designs directly in markup.
- Relevanz für NALA-DNA-Med: Fits NALA Black Edition UI: gunmetal surfaces, emerald neon accents, responsive dashboard cards.

### Authentik Documentation

- Bereich: Security / Authentication
- Link: https://docs.goauthentik.io/
- Original-Kernaussage / Zusammenfassung: Authentik documentation covers open-source identity provider functionality such as authentication, SSO and user management.
- Relevanz für NALA-DNA-Med: Possible later identity layer for multi-user access, 2FA and external users. Not needed for v0.1, but useful for committee-grade deployment.

### Keycloak Documentation

- Bereich: Security / Authentication
- Link: https://www.keycloak.org/documentation
- Original-Kernaussage / Zusammenfassung: Keycloak documentation covers open-source identity and access management for modern apps and services.
- Relevanz für NALA-DNA-Med: Alternative to Authentik for mature SSO/realm/role based access management.
