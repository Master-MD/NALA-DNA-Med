# NALA-DNA-Med aPP — MASTERPLAN / README / FAQ / CAVEMAN Install

**Repo-Ziel:** https://github.com/Master-MD/NALA-DNA-Med-  
**Autor/Owner:** Michael Dreher / Master-MD  
**Datum:** 2026-05-27  
**Status:** Konzept + Codex-Masterprompt + MVP-Spezifikation  
**Style:** NALA Black Edition — Gunmetal, Emerald Neon, Industrial, ADHS-freundlich

> **Wichtiger medizinischer Hinweis:** NALA-DNA-Med ist als lokale Forschungs-, Lern-, Screening- und Hypothesenhilfe gedacht. Es ist **kein Medizinprodukt**, nicht klinisch validiert und darf keine Diagnose, Therapieempfehlung oder Medikamentenfreigabe ersetzen.

---

## 0. TL;DR

NALA-DNA-Med aPP soll eine lokale, datenschutzfreundliche Bio-/Drug-Discovery-Forschungsapp im NALA-cORe-Ökosystem werden.

**Empfohlene Architektur:** Hybrid.

- **Local Lite Mode:** läuft direkt auf dem MacBook Pro ohne Docker/OrbStack.
- **OrbStack Core Mode:** startet Qdrant, Postgres, MinIO, Redis, API, BioModel-Service und UI via Docker Compose.
- **Später:** Proxmox/Dell/NVIDIA GPU als Heavy Worker für echte Modell-Inferenz, Docking und Batch-Jobs.

**Warum Hybrid?**  
All-in-One fühlt sich für Nutzer einfacher an, aber Bio-/RAG-/DB-Services bleiben in Containern viel sauberer wartbar.

---

## 1. Zielbild

```text
NALA-DNA-Med aPP
├─ Local Lite Mode
│  ├─ UI
│  ├─ lokale Projektverwaltung
│  ├─ BioLab-Demo/Dry-Run
│  └─ File Vault
│
└─ OrbStack Core Mode
   ├─ nala-api / FastAPI
   ├─ nala-ui / React + Vite
   ├─ biomodel-api / MAMMAL-Plugin später
   ├─ PostgreSQL / Metadata
   ├─ Qdrant / RAG Vector DB
   ├─ MinIO / Object Storage
   ├─ Redis / Job Queue
   └─ TenantShield / Rechte, Filter, Audit
```

---

## 2. Warum nicht sofort eine schwere native Desktop-App?

Eine echte native Desktop-App, die PyTorch, RDKit, Qdrant, Postgres, MinIO, Redis, Modellgewichte und Worker in ein Paket presst, wird schnell fragil.

**Besser:**

- App/UI bleibt einfach.
- Services laufen reproduzierbar.
- Docker/OrbStack kapselt Abhängigkeiten.
- Local Lite bleibt für Demo/Einzeluser verfügbar.
- Core Mode ist später serverfähig.

---

## 3. MacBook-Pro-Tauglichkeit

| Modus | Läuft auf MacBook Pro? | Einschätzung |
|---|---:|---|
| Local Lite UI/API | Ja | sehr wahrscheinlich |
| OrbStack Core mit DBs/Services | Ja | sehr wahrscheinlich |
| Kleine Bio-Demos | Ja | wahrscheinlich |
| MAMMAL via CPU/MPS | Möglich | testen nötig |
| grosse Drug-Discovery-Batches | eher Dell/Proxmox/NVIDIA | empfohlen |

Apple Silicon kann PyTorch über den MPS-Backend beschleunigen; trotzdem sollten CPU-Fallbacks eingebaut werden, weil nicht jede Operation stabil/performant auf MPS läuft.

---

## 4. Mockup Screenshots

### 4.1 System Check / CAVEMAN Mode

![System Check](mockups/01_system_check.png)

### 4.2 Dashboard

![Dashboard](mockups/02_dashboard.png)

### 4.3 BioLab Demo

![BioLab Demo](mockups/03_biolab_demo.png)

---

## 5. MVP-Funktionen v0.1

### Muss können

- GitHub-ready Repo-Struktur
- Mac-first Local Lite Mode
- Optionaler OrbStack Core Mode
- Doctor Script
- Dry-Run Install
- Start/Stop Scripts
- Backup/Restore Scripts
- NALA Black UI
- BioLab Dry-Run
- Tenant- und Projektmodell
- Audit Log
- Medical Safety Banner

### Darf in v0.1 nur vorbereitet sein

- echtes MAMMAL-Modell
- RDKit
- BioPython
- Docking
- Full RAG
- Multi-GPU
- externe User via HTTPS/2FA

---

## 6. Multi-User / Datenschutzmodell

Der wichtigste Grundsatz:

```text
Ein Modell darf gemeinsam genutzt werden.
Datenräume dürfen nicht vermischt werden.
```

Jedes Objekt bekommt:

```json
{
  "tenant_id": "tenant_mike",
  "user_id": "user_mike",
  "project_id": "project_biolab_demo",
  "created_at": "...",
  "updated_at": "..."
}
```

Jede RAG-Suche muss zwingend filtern:

```json
{
  "must": [
    {"key": "tenant_id", "match": {"value": "tenant_mike"}},
    {"key": "project_id", "match": {"value": "project_biolab_demo"}}
  ]
}
```

**Keine Suche ohne tenant_id + project_id.**

---

## 7. Sicherheitsregeln

### NALA TenantShield

TenantShield blockiert:

- RAG-Abfrage ohne Tenant/Projekt
- Tool-Aufruf ohne User-Kontext
- Export fremder Dokumente
- Training/Fine-Tuning mit Userdaten ohne Freigabe
- Löschen ohne explizite Bestätigung

### Audit Events

Jeder relevante Vorgang schreibt:

- user_id
- tenant_id
- project_id
- action
- tool/service
- timestamp
- risk level
- result summary

---

## 8. Vorgeschlagene Repo-Struktur

```text
NALA-DNA-Med-
├── README.md
├── TODO.md
├── .env.example
├── docker-compose.yml
├── docs/
│   ├── VISION.md
│   ├── ARCHITECTURE.md
│   ├── SECURITY.md
│   ├── MULTI_TENANT_MODEL.md
│   ├── BIOMEDICAL_SAFETY.md
│   ├── FAQ.md
│   └── ROADMAP.md
├── scripts/
│   ├── nala-doctor.sh
│   ├── nala-install.sh
│   ├── nala-start.sh
│   ├── nala-stop.sh
│   ├── nala-backup.sh
│   └── nala-restore.sh
├── apps/
│   ├── web/
│   ├── api/
│   └── biomodel/
├── packages/
│   └── shared/
├── data/
│   └── .gitkeep
├── backups/
│   └── .gitkeep
└── mockups/
    ├── 01_system_check.png
    ├── 02_dashboard.png
    └── 03_biolab_demo.png
```

---

## 9. CAVEMAN Installation

### 9.1 Du willst nur starten und nichts kaputt machen

```bash
git clone https://github.com/Master-MD/NALA-DNA-Med-.git
cd NALA-DNA-Med-
./scripts/nala-doctor.sh
./scripts/nala-install.sh --dry-run
```

Wenn alles grün ist:

```bash
./scripts/nala-install.sh
./scripts/nala-start.sh
```

### 9.2 OrbStack Core Mode

OrbStack starten, dann:

```bash
./scripts/nala-doctor.sh
./scripts/nala-install.sh --dry-run --core
./scripts/nala-install.sh --core
./scripts/nala-start.sh --core
```

### 9.3 Stoppen

```bash
./scripts/nala-stop.sh
```

### 9.4 Backup

```bash
./scripts/nala-backup.sh
```

### 9.5 Restore

```bash
./scripts/nala-restore.sh
```

---

## 10. Empfohlene Ports

Scripts sollen Ports automatisch prüfen und nicht blind überschreiben.

| Dienst | Wunschport | Verhalten |
|---|---:|---|
| UI | 5173 | nächster freier Port |
| API | 8710 | nächster freier Port |
| BioModel API | 8720 | nächster freier Port |
| Qdrant | 6333 | nächster freier Port |
| Postgres | 5432 | nächster freier Port |
| Redis | 6379 | nächster freier Port |
| MinIO | 9000/9001 | nächste freie Ports |

---

## 11. Codex MASTERPROMPT

Kopiere diesen Prompt in Codex, nachdem du das GitHub-Repo erstellt/geöffnet hast.

```text
You are Codex working as a senior full-stack software architect and safety-focused local AI systems engineer.

Repository:
https://github.com/Master-MD/NALA-DNA-Med-

Build a new GitHub-ready project called:

NALA-DNA-Med-aPP

Goal:
Create a macOS-first, local-first, privacy-preserving biomedical research app for the NALA-cORe ecosystem. The app should support a simple all-in-one user experience, but internally it must support two runtime modes:

1. Local Lite Mode:
- Runs directly on macOS.
- Starts a local web UI and lightweight backend.
- Uses local filesystem storage.
- Supports project creation, upload placeholders, health checks, and demo analysis.
- Must work even if Docker/OrbStack is not installed.

2. OrbStack Core Mode:
- Uses Docker Compose via OrbStack or Docker-compatible engine.
- Starts backend services:
  - nala-api: FastAPI backend
  - nala-ui: frontend
  - postgres: metadata database
  - qdrant: vector database
  - minio: object/file storage
  - redis: job queue
  - biomodel-api: biomedical model service placeholder
- Must be designed so real biomedical models like IBM MAMMAL / ibm-research/biomed.omics.bl.sm.ma-ted-458m can be integrated later.
- Must not require the real model download in v0.1.
- Must include a stub model endpoint and a dry-run biomedical inference simulation.

Primary design principles:
- Local-first.
- Privacy-first.
- Multi-user-ready from day one.
- Strict tenant isolation.
- No cross-user data leakage.
- No shared RAG results without explicit project sharing.
- No medical diagnosis or treatment recommendations.
- Everything must be auditable.
- Everything must be recoverable.
- Safe defaults.
- Dark NALA Black Edition UI style.

Repository requirements:
Create a complete repo structure with:

/README.md
/docs/VISION.md
/docs/ARCHITECTURE.md
/docs/SECURITY.md
/docs/MULTI_TENANT_MODEL.md
/docs/BIOMEDICAL_SAFETY.md
/docs/FAQ.md
/docs/ROADMAP.md
/scripts/nala-install.sh
/scripts/nala-doctor.sh
/scripts/nala-start.sh
/scripts/nala-stop.sh
/scripts/nala-backup.sh
/scripts/nala-restore.sh
/docker-compose.yml
/.env.example
/apps/web
/apps/api
/apps/biomodel
/packages/shared
/data/.gitkeep
/backups/.gitkeep
/mockups

Technology preference:
- Frontend: React + Vite + TypeScript + Tailwind
- Backend: FastAPI + Python
- Database: PostgreSQL
- Vector DB: Qdrant
- Object Storage: MinIO
- Queue: Redis
- Biomedical model service: Python FastAPI stub in v0.1
- Package scripts should be simple.
- Docker Compose must work with OrbStack on macOS.
- Local Lite Mode must work without Docker.

NALA style:
Use a dark industrial UI:
- black / graphite / gunmetal
- emerald neon accents
- subtle glitch details
- clear dashboard cards
- ADHS-friendly visual feedback
- no clutter
- no sound by default

Critical safety requirement:
Before making any system changes, scripts must:
1. Detect OS and architecture.
2. Detect whether OrbStack or Docker is installed.
3. Detect occupied ports.
4. Detect existing data directories.
5. Create timestamped backups before changing files.
6. Never delete data without explicit confirmation.
7. Print a clear risk estimate:
   "Estimated: xx% success / xx% unknown / xx% fail"
8. Support dry-run mode:
   --dry-run
9. Support verbose mode:
   --verbose
10. Support rollback or restore instructions.

Ports:
Do not hardcode ports blindly.
Default preferred ports:
- UI: 5173 or next free
- API: 8710 or next free
- BioModel API: 8720 or next free
- Qdrant: 6333 or next free
- Postgres: 5432 or next free
- Redis: 6379 or next free
- MinIO: 9000/9001 or next free
The scripts must detect port conflicts and generate a local .env file with free ports.

Multi-user / tenant model:
Every database entity must include:
- tenant_id
- user_id where applicable
- project_id where applicable
- created_at
- updated_at

Implement initial tables:
- tenants
- users
- projects
- documents
- jobs
- audit_events

RAG / Vector model:
For v0.1, do not implement full RAG if it increases complexity too much.
But design the structure:
- Qdrant collection name: nala_dna_med_embeddings_v1
- Every vector payload must include tenant_id, user_id, project_id, document_id.
- Every retrieval query must enforce tenant_id and project_id filters.
- Add code comments and tests to ensure no query can run without tenant/project filter.

Biomedical model:
Implement a stub biomodel-api with endpoints:
GET /health
POST /predict/smiles
POST /predict/protein
POST /jobs/dry-run

The stub should return fake but clearly marked demo results:
- "demo_mode": true
- "not_medical_advice": true
- "confidence": "low"
- "warnings": [...]
No real biomedical claim should be made in v0.1.

Later integration target:
- IBM MAMMAL / ibm-research/biomed.omics.bl.sm.ma-ted-458m
- RDKit
- BioPython
- optional docking tools
Do not install these heavy dependencies automatically in v0.1.
Create a documented plugin folder and integration notes.

UI screens:
1. Welcome / System Check
2. Runtime Mode Selector:
   - Local Lite Mode
   - OrbStack Core Mode
3. Dashboard
4. Tenants / Users placeholder
5. Projects
6. Upload Center
7. BioLab Demo:
   - SMILES input
   - Protein sequence input
   - run dry-run
8. Jobs
9. Audit Log
10. Settings
11. Backup / Restore

API requirements:
- FastAPI
- /health
- /system/check
- /tenants
- /projects
- /documents
- /jobs
- /audit
- /biolab/dry-run

Tests:
Create basic tests:
- API health test
- tenant isolation test
- project creation test
- biomodel dry-run test
- port detection test if possible

Scripts:
nala-doctor.sh:
- prints OS, architecture, shell, Python version, Node version, Docker/OrbStack status, free ports, disk space, git status if repo exists.
- must not change anything.

nala-install.sh:
- supports --dry-run.
- checks dependencies.
- creates .env.local from .env.example.
- creates required directories.
- does not download heavy models.
- asks before installing missing dependencies.

nala-start.sh:
- starts Local Lite Mode by default.
- supports --core to start Docker Compose.
- detects OrbStack/Docker.
- prints URLs.

nala-stop.sh:
- stops local processes or docker compose services.

nala-backup.sh:
- creates timestamped backup under backups/.
- includes .env.local, database dumps if available, app config, but never includes model caches by default unless --include-models.

nala-restore.sh:
- lists backups.
- restores only after explicit confirmation.

README:
Must include:
- What this app is
- What it is not
- Medical safety warning
- Quickstart Local Lite Mode
- Quickstart OrbStack Core Mode
- Architecture overview
- Data isolation model
- Development commands
- Troubleshooting
- Roadmap
- License placeholder

Important:
Do not create fake claims that the biomedical model is already integrated.
Do not claim the system can discover real medication.
Use "research support", "screening assistance", "hypothesis generation", and "education/demo" language.
Add visible disclaimers:
"This system is not medical advice and not validated for diagnosis or treatment."

Deliverables:
1. Generate the full repository files.
2. Make the MVP startable.
3. Run tests or provide exact commands.
4. If anything cannot be completed, write a clear TODO.md with blockers.
5. Keep implementation simple, robust, and readable.
```

---

## 12. Codex AUDIT/FIX Prompt

Nach dem ersten Build:

```text
Now audit the generated NALA-DNA-Med-aPP repo.

Perform a safety and consistency review:

1. Check whether Local Lite Mode can start without Docker.
2. Check whether OrbStack Core Mode can start via docker compose.
3. Check whether all required docs exist.
4. Check whether tenant_id/project_id are enforced in database models and API routes.
5. Check whether any code path can access documents without tenant/project filter.
6. Check whether ports are hardcoded unsafely.
7. Check whether scripts support --dry-run.
8. Check whether backups are timestamped.
9. Check whether any script can delete user data without explicit confirmation.
10. Check whether the UI clearly says "not medical advice".
11. Check whether heavy biomedical model downloads are avoided in v0.1.
12. Check whether the README commands are actually correct.

Then produce:
- AUDIT_REPORT.md
- FIX_PLAN.md
- PATCHES
- Updated success/risk estimate:
  xx% success / xx% unknown / xx% fail

Do not expand scope.
Fix only MVP blockers.
```

---

## 13. FAQ

### Ist das eine App, die Medikamente entwickelt?

Nein. Es ist eine lokale Forschungs- und Hypothesenhilfe. Sie kann später beim Sortieren, Suchen, RAG, Screening und Dokumentieren helfen. Echte Arzneimittelforschung braucht Laborvalidierung, Toxikologie, Fachpersonen und regulatorische Prüfung.

### Läuft das auf meinem MacBook Pro?

Für UI, Local Lite, OrbStack Core und kleine Demos: ja, sehr wahrscheinlich. Für schwere Bio-Modelle und grosse Batch-Jobs ist später deine Dell/Proxmox/NVIDIA-Schiene besser.

### Muss OrbStack installiert sein?

Nicht für Local Lite Mode. Für Core Mode ja, oder eine Docker-kompatible Alternative.

### Warum nicht einfach Open WebUI nehmen?

Open WebUI ist super als MVP-/Admin-/Chat-Oberfläche, aber NALA-DNA-Med braucht langfristig eigene Workflows: Projekte, Upload Center, BioLab, Audit, TenantShield, ReportKit.

### Können mehrere Nutzer zugreifen?

Ja, aber nur wenn TenantShield, Auth, Rollen, Audit und RAG-Filter korrekt implementiert sind. In v0.1 wird das Modell vorbereitet, nicht öffentlich freigeschaltet.

### Können Daten von Nutzer A bei Nutzer B landen?

Das darf nie passieren. Deshalb müssen tenant_id und project_id auf DB-, Storage- und RAG-Ebene erzwungen werden.

### Werden echte MAMMAL-Modelle sofort installiert?

Nein. v0.1 soll keine schweren Modelle automatisch laden. Erst Stub, dann Plugin-Integration.

### Was ist CAVEMAN Install?

Die idiotensichere Installation:

1. Doctor
2. Dry-Run
3. Backup
4. Install
5. Start
6. Wenn kaputt: Restore

---

## 14. Roadmap

### v0.1 — Safe Skeleton

- Repo-Struktur
- Scripts
- UI Mock
- FastAPI
- BioModel Stub
- Tenant-Modell
- Audit Log
- Docker Compose

### v0.2 — Local Lite produktiver

- lokale Projektverwaltung
- Uploads
- einfache Parser
- bessere UI
- local JSON/SQLite fallback

### v0.3 — RAGVault

- Qdrant aktiv
- Dokumentenparser
- Embeddings
- harte Tenant-Filter
- Quellen im Report

### v0.4 — Bio Plugins

- RDKit
- BioPython
- MAMMAL Adapter
- SMILES/FASTA Checks
- Modell-Capability Matrix

### v0.5 — Multi-User Core

- Authentik/Keycloak
- Rollen
- 2FA
- Gruppen
- Projektfreigaben
- externe Nutzer nur über VPN/Tailscale/HTTPS

### v1.0 — NALA BioLab

- Projektboards
- ReportKit
- Audit Export
- Backup/Restore
- Proxmox GPU Worker
- Docker/OrbStack/Server Mode

---

## 15. Quellen

### MAMMAL / IBM Biomedical Foundation Model

- GitHub: https://github.com/BiomedSciAI/biomed-multi-alignment
- Hugging Face: https://huggingface.co/ibm-research/biomed.omics.bl.sm.ma-ted-458m
- Paper: https://arxiv.org/abs/2410.22367

### Open WebUI / RBAC

- RBAC Overview: https://docs.openwebui.com/features/authentication-access/rbac/
- Permissions: https://docs.openwebui.com/features/authentication-access/rbac/permissions/
- Groups: https://docs.openwebui.com/features/authentication-access/rbac/groups/
- Roles: https://docs.openwebui.com/features/authentication-access/rbac/roles/

### Qdrant / Multitenancy

- Multitenancy: https://qdrant.tech/documentation/manage-data/multitenancy/
- Filtering: https://qdrant.tech/documentation/search/filtering/

### vLLM

- OpenAI-compatible server: https://docs.vllm.ai/en/latest/serving/openai_compatible_server.html
- Quickstart: https://docs.vllm.ai/en/stable/getting_started/quickstart/

### OrbStack

- Quickstart: https://orbstack.dev/docs/quick-start
- Docker containers: https://docs.orbstack.dev/docker/
- OrbStack vs Docker Desktop: https://orbstack.dev/docs/compare/docker-desktop

### Apple Silicon / PyTorch MPS

- Apple: https://developer.apple.com/metal/pytorch/
- PyTorch MPS notes: https://docs.pytorch.org/docs/stable/notes/mps.html

### Bio/Chem Tools

- RDKit Install: https://www.rdkit.org/docs/Install.html
- FastAPI: https://fastapi.tiangolo.com/

---

## 16. Risiko-/Erfolgsschätzung

### MVP Skeleton

```text
85% success / 10% unknown / 5% fail
```

### OrbStack Core Mode

```text
80% success / 15% unknown / 5% fail
```

### MAMMAL lokal auf MacBook Pro

```text
55% success / 35% unknown / 10% fail
```

### MAMMAL/BioLab auf Dell/Proxmox/NVIDIA

```text
75% success / 20% unknown / 5% fail
```

---

## 17. Was unsicher bleibt

- Ob MAMMAL auf deinem exakten MacBook Pro mit MPS ohne Anpassungen sauber läuft.
- Welche MAMMAL-Tasks zuerst stabil in eine API gekapselt werden sollten.
- Wie gross die ersten echten Modellgewichte/Caches praktisch werden.
- Ob das GitHub-Repo bereits Dateien enthält, die Codex berücksichtigen muss.
- Welche Auth-Lösung du später final willst: Authentik, Keycloak, Open WebUI RBAC oder eigene NALA Auth.

---

## 18. Empfehlung für nächsten Schritt

1. Repo öffnen: `https://github.com/Master-MD/NALA-DNA-Med-`
2. Codex starten.
3. MASTERPROMPT aus Kapitel 11 einfügen.
4. Codex zuerst nur Skeleton bauen lassen.
5. Danach AUDIT/FIX Prompt aus Kapitel 12.
6. Erst dann MAMMAL/RDKit als Plugin-Branch planen.
