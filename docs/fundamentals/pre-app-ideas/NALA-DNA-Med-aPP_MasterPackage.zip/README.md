# NALA-DNA-Med aPP

Local-first, privacy-first biomedical research helper for the NALA-cORe ecosystem.

> Not medical advice. Not validated for diagnosis or treatment.

## Quickstart

```bash
git clone https://github.com/Master-MD/NALA-DNA-Med-.git
cd NALA-DNA-Med-
./scripts/nala-doctor.sh
./scripts/nala-install.sh --dry-run
./scripts/nala-install.sh
./scripts/nala-start.sh
```

## Core Mode

```bash
./scripts/nala-start.sh --core
```

## Concept package

See `NALA-DNA-Med-aPP_MASTER.md`.
