# Architecture

Hybrid: Local Lite Mode plus OrbStack Core Mode. Shared models, isolated tenant/project data.
