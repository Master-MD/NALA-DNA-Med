# Security

TenantShield enforces tenant_id and project_id on all data access. No delete without confirmation. Audit every tool call.
