# Vision

NALA-DNA-Med aPP is a local-first biomedical research helper for screening support, RAG, project vaults, and auditable workflows.
